<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    
    <form method="post" action="MainPage.php"> 
               
      Email:    <input type="text" size="30" name="email"/> <br>
      Password: <input type="text" size="30" name="password"/><br>
           <input type="submit" value="Login"> 

    </form> 
    </body>
</html>
